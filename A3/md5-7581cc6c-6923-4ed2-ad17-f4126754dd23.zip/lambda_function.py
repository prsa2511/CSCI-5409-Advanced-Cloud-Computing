import json
import hashlib
import urllib.request
import urllib.parse

def lambda_handler(event, context):
    
    # Get the endpoint URL from the input JSON
    course_uri = event.get('course_uri')
    if not course_uri:
        return {
            'statusCode': 400,
            'body': json.dumps('Error: Please provide course_uri in the event.')
        }

    # Get the string to encrypt from the event
    input_string = event.get('value')
    if not input_string:
        return {
            'statusCode': 400,
            'body': json.dumps('Error: Please provide value in the event.')
        }

    # Encrypt the string using MD5
    input_bytes = input_string.encode('utf-8')  # Encode the input string to bytes using UTF-8
    encrypted_bytes = hashlib.md5(input_bytes).digest()
    encrypted_string = encrypted_bytes.hex()  # Convert the encrypted bytes to hexadecimal string
	
    # Prepare the response JSON
    response_json = {
        "banner": "B00954261", 
        "result": encrypted_string,
        "arn": "arn:aws:lambda:us-east-1:590183742473:function:md5",
        "action": "md5",
        "value": input_string
    }
    
    # Convert the response JSON to string
    response_body = json.dumps(response_json)
    
    # Post the response to the endpoint serverless/end
    headers = {'Content-Type': 'application/json'}
    request = urllib.request.Request(course_uri, data=response_body.encode('utf-8'), headers=headers)
    try:
        with urllib.request.urlopen(request) as response:
            if response.status == 200:
                return json.dumps(response_json)
            else:
                return {
                    'statusCode': response.status,
                    'body': json.dumps('Error posting response to the endpoint.')
                }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error: {str(e)}')
        }
