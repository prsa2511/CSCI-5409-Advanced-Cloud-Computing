import json
import hashlib
import urllib.request
import urllib.parse

def lambda_handler(event, context):
    
	# Extract the endpoint URL from the input data
	course_uri = event.get('course_uri')
	if not course_uri:
		return {
			'statusCode': 400,
			'body': json.dumps('Error: course_uri is missing in the input.')
		}

	# Retrieve the data to be encrypted from the event
	data_to_encrypt = event.get('value')
	if not data_to_encrypt:
		return {
			'statusCode': 400,
			'body': json.dumps('Error: value is missing in the input.')
		}

	# Perform SHA-256 encryption on the input data
	data_bytes = data_to_encrypt.encode('utf-8')  # Convert the data into bytes using UTF-8 encoding
	sha256_encrypted_bytes = hashlib.sha256(data_bytes).digest()  # Encrypt the data and get hex string
	sha256_encrypted_data = sha256_encrypted_bytes.hex()

	# Construct the response dictionary
	response_data = {
		"banner": "B00954261", 
		"result": sha256_encrypted_data,
		"arn": "arn:aws:lambda:us-east-1:590183742473:function:sha256",
		"action": "sha256",
		"value": data_to_encrypt
	}
    
	# Serialize the response data to JSON string
	serialized_response = json.dumps(response_data)
	
	# Sending the encrypted data to the specified endpoint
	request_headers = {'Content-Type': 'application/json'}
	post_request = urllib.request.Request(course_uri, data=serialized_response.encode('utf-8'), headers=request_headers)
	try:
		with urllib.request.urlopen(post_request) as server_response:
			if server_response.status == 200:
				return json.dumps(response_data)
			else:
				return {
					'statusCode': server_response.status,
					'body': json.dumps('Failed to post encrypted data to the endpoint.')
						}
	except Exception as error:
		return {
			'statusCode': 500,
			'body': json.dumps(f'Error encountered: {str(error)}')
				}
