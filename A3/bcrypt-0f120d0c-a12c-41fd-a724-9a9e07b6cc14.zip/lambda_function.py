import json
import bcrypt
import urllib.request
import urllib.parse

def lambda_handler(event, context):
    
	# Extract the URL for the API call from the incoming JSON data
	target_url = event.get('course_uri')
	if not target_url:
		return {
			'statusCode': 400,
			'body': json.dumps('Missing required parameter: course_uri.')
		}

	# Retrieve the text to be encrypted from the request data
	text_for_encryption = event.get('value')
	if not text_for_encryption:
		return {
			'statusCode': 400,
			'body': json.dumps('Missing required parameter: value.')
		}

	try:
		# Perform encryption using bcrypt
		encryption_salt = bcrypt.gensalt()
		text_bytes = text_for_encryption.encode('utf-8')  # Encoding the text to bytes
		hashed_bytes = bcrypt.hashpw(text_bytes, encryption_salt)
		hashed_text = hashed_bytes.decode('utf-8')  # Decoding the hashed bytes back to a string
	except Exception as error:
		return {
			'statusCode': 500,
			'body': json.dumps(f'Encryption error: {str(error)}')
		}
        
	# Structure the response data
	api_response_data = {
		"banner": "B00954261",
		"result": hashed_text,
		"arn": "arn:aws:lambda:us-east-1:590183742473:function:bcrypt",
		"action": "bcrypt",
		"value": text_for_encryption
	}

	# Serializing the response data to a JSON string
	serialized_response = json.dumps(api_response_data)

	# Sending the response back to the provided endpoint URL
	response_headers = {'Content-Type': 'application/json'}
	api_request = urllib.request.Request(target_url, data=serialized_response.encode('utf-8'), headers=response_headers)
	try:
		with urllib.request.urlopen(api_request) as server_response:
			if server_response.status == 200:
				return json.dumps(api_response_data)
			else:
				return {
					'statusCode': server_response.status,
					'body': json.dumps('Failed to deliver response to the endpoint.')
				}
	except Exception as network_error:
		return {
			'statusCode': 500,
			'body': json.dumps(f'Network error: {str(network_error)}')
		}
